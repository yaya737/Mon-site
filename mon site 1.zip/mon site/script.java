// Fonction pour filtrer les liens en fonction de la recherche
function searchLinks() {
  var input, filter, links, a, i, txtValue;
  input = document.getElementById("searchBar");
  filter = input.value.toLowerCase();
  links = document.getElementById("links").getElementsByTagName("p");

  // Parcourir tous les paragraphes contenant des liens
  for (i = 0; i < links.length; i++) {
    a = links[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;

    // Afficher les liens correspondant à la recherche
    if (txtValue.toLowerCase().indexOf(filter) > -1) {
      links[i].style.display = "";
    } else {
      links[i].style.display = "none";
    }
  }
}
